export function BasicLayout(props) {
  const { children } = props;

  return children;
}
