import React from "react";

export function Error404() {
  return (
    <div>
      <h3>Error404</h3>
    </div>
  );
}
